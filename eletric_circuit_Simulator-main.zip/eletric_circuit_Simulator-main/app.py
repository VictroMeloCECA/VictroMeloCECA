import tkinter as tk
from tkinter import filedialog
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

class CircuitSimulator:
    def __init__(self, root) -> None:
        self.root = root
        self.root.title("Simulador de Circuitos Elétricos- CECA 2024")
        
        self.canvas = tk.Canvas(root, width=600, height=600, bg='white')
        self.circuit_boundary = self.canvas.create_rectangle(100, 100, 500, 500)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.add_grid()

        # Gráfico
        self.fig = Figure(figsize=(5, 4), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_title('Gráfico de Corrente x Tensão')
        self.ax.set_xlabel('Tensão (V)')
        self.ax.set_ylabel('Corrente (A)')
        self.chart = FigureCanvasTkAgg(self.fig, master=root)
        self.chart.get_tk_widget().pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Botões
        self.add_resistor_button = tk.Button(root, text="Adicionar Resistor", command=self.add_resistor)
        self.add_resistor_button.pack(side=tk.TOP, padx=5, pady=5)

        self.add_resistor_group_button = tk.Button(root, text="Adicionar Grupo de Resistores em Paralelo", command=self.add_resistor_group)
        self.add_resistor_group_button.pack(side=tk.TOP, padx=5, pady=5)

        self.add_voltage_source_button = tk.Button(root, text="Adicionar Fonte de Tensão", command=self.add_voltage_source)
        self.add_voltage_source_button.pack(side=tk.TOP, padx=5, pady=5)

        self.add_line_button = tk.Button(root, text="Adicionar Linha", command=self.start_line_creation)
        self.add_line_button.pack(side=tk.TOP, padx=5, pady=5)

        self.plot_graph_button = tk.Button(root, text="Plotar Gráfico", command=self.plot_graph)
        self.plot_graph_button.pack(side=tk.TOP, padx=5, pady=5)

        self.export_graph_button = tk.Button(root, text="Exportar Gráfico", command=self.export_graph)
        self.export_graph_button.pack(side=tk.TOP, padx=5, pady=5)

        # Campo de texto para mostrar os resultados
        self.results_label = tk.Label(root, text="Resistência Equivalente: 0 Ohms\nCorrente Total: 0 Amperes\nTensão Total: 0 Volts", font=("Arial", 12))
        self.results_label.pack(side=tk.TOP, pady=5)

        # Inicialização dos componentes
        self.components = []
        self.resistor_groups = []
        self.current_line = None
        self.start_x = None
        self.start_y = None

        # Contadores para resistores e fontes de tensão
        self.resistor_count = 1
        self.voltage_source_count = 1

    def add_grid(self):
        # Adicionar linhas da grade
        for i in range(100, 600, 20):
            self.canvas.create_line(i, 100, i, 500, fill='lightgray', dash=(2, 2))
            self.canvas.create_line(100, i, 500, i, fill='lightgray', dash=(2, 2))


    def start_line_creation(self):
        self.canvas.bind("<Button-1>", self.on_canvas_click)
        self.canvas.bind("<B1-Motion>", self.on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_canvas_release)

    def on_canvas_click(self, event):
        if self.current_line:
            self.canvas.delete(self.current_line)
        self.start_x = event.x
        self.start_y = event.y
        self.current_line = self.canvas.create_line(self.start_x, self.start_y, self.start_x, self.start_y, fill='black')

    def on_canvas_drag(self, event):
        if self.current_line:
            self.canvas.coords(self.current_line, self.start_x, self.start_y, event.x, event.y)

    def on_canvas_release(self, event):
        if self.current_line:
            # Finaliza a linha
            self.canvas.coords(self.current_line, self.start_x, self.start_y, event.x, event.y)
            self.current_line = None
            self.start_x = None
            self.start_y = None
            # Desassocia os eventos de arrastar e soltar
            self.canvas.unbind("<Button-1>")
            self.canvas.unbind("<B1-Motion>")
            self.canvas.unbind("<ButtonRelease-1>")
            # Atualiza os resultados após adicionar a linha
            self.update_results()

    def add_resistor(self):
        x, y = 200, 150
        resistance = float(tk.simpledialog.askstring("Input", "Valor da resistência (Ohms):"))
        resistor_name = f"R{self.resistor_count}"
        resistor = Resistor(self.canvas, x, y, resistance, self, resistor_name)
        self.components.append(resistor)
        self.resistor_count += 1
        self.update_results()

    def add_resistor_group(self):
        resistor_count = int(tk.simpledialog.askstring("Input", "Número de resistores no grupo:"))
        resistors = []
        for i in range(resistor_count):
            resistance = float(tk.simpledialog.askstring("Input", "Valor da resistência (Ohms):"))
            resistor_name = f"R{self.resistor_count}"
            resistor = Resistor(self.canvas, 200 + i*20, 150, resistance, self, resistor_name)
            resistors.append(resistor)
            self.components.append(resistor)
            self.resistor_count += 1
        
        group = ResistorGroup(self.canvas, resistors)
        self.resistor_groups.append(group)
        self.update_results()

    def add_voltage_source(self):
        x, y = 150, 200
        voltage = float(tk.simpledialog.askstring("Input", "Valor da tensão (Volts):"))
        voltage_name = f"V{self.voltage_source_count}"
        voltage_source = VoltageSource(self.canvas, x, y, voltage, self, voltage_name)
        self.components.append(voltage_source)
        self.voltage_source_count += 1
        self.update_results()

    def calculate_resistance(self):
        # Calcula a resistência equivalente considerando grupos de resistores e resistores individuais
        parallel_resistances = [group.calculate_parallel_resistance() for group in self.resistor_groups]
        total_resistance_in_series = sum(parallel_resistances)
        for component in self.components:
            if isinstance(component, Resistor) and component not in [res for group in self.resistor_groups for res in group.resistors]:
                total_resistance_in_series += component.resistance
        return total_resistance_in_series

    def calculate_total_voltage(self):
        voltages = [comp.voltage for comp in self.components if isinstance(comp, VoltageSource)]
        return sum(voltages) if voltages else 0

    def calculate_total_current(self, resistance_eq, total_voltage):
        if resistance_eq > 0:
            return total_voltage / resistance_eq
        return 0

    def update_results(self):
        resistance_eq = self.calculate_resistance()
        total_voltage = self.calculate_total_voltage()
        total_current = self.calculate_total_current(resistance_eq, total_voltage)
        
        self.results_label.config(
            text=f"Resistência Equivalente: {resistance_eq:.2f} Ohms\n"
                 f"Corrente Total: {total_current:.2f} Amperes\n"
                 f"Tensão Total: {total_voltage:.2f} Volts"
        )

    def plot_graph(self):
        # Dados de exemplo para o gráfico
        resistance_eq = self.calculate_resistance()
        total_voltage = self.calculate_total_voltage()
        
        voltages = np.linspace(0, total_voltage, 100)
        currents = voltages / resistance_eq if resistance_eq != 0 else np.zeros_like(voltages)
        
        self.ax.clear()
        self.ax.plot(voltages, currents, label='Corrente x Tensão')
        self.ax.set_title('Gráfico de Corrente x Tensão')
        self.ax.set_xlabel('Tensão (V)')
        self.ax.set_ylabel('Corrente (A)')
        self.ax.legend()
        self.chart.draw()

    def export_graph(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"), ("All files", "*.*")])
        if file_path:
            self.fig.savefig(file_path)

class Resistor:
    def __init__(self, canvas, x, y, resistance, simulator, name):
        self.canvas = canvas
        self.x, self.y = x, y
        self.resistance = resistance
        self.simulator = simulator
        self.name = name

        # Desenhar resistor em formato de "W"
        self.body = self.canvas.create_line(x, y, x+10, y-20, x+20, y+20, x+30, y-20, x+40, y+20, x+50, y-20, x+60, y, fill='black')
        self.name_text = self.canvas.create_text(x + 30, y + 30, text=f"{self.name} ({self.resistance}Ω)", font=("Arial", 10))

        # Associar o movimento ao resistor
        self.canvas.tag_bind(self.body, "<Button1-Motion>", self.move)
        self.canvas.tag_bind(self.name_text, "<Button1-Motion>", self.move)

    def move(self, event):
        dx, dy = event.x - self.x, event.y - self.y
        self.canvas.move(self.body, dx, dy)
        self.canvas.move(self.name_text, dx, dy)
        self.x, self.y = event.x, event.y
        self.simulator.update_results()

class ResistorGroup:
    def __init__(self, canvas, resistors):
        self.canvas = canvas
        self.resistors = resistors

    def calculate_parallel_resistance(self):
        reciprocal_resistances = [1 / resistor.resistance for resistor in self.resistors]
        total_reciprocal = sum(reciprocal_resistances)
        return 1 / total_reciprocal if total_reciprocal != 0 else float('inf')

class VoltageSource:
    def __init__(self, canvas, x, y, voltage, simulator, name):
        self.canvas = canvas
        self.x, self.y = x, y
        self.voltage = voltage
        self.radius = 20
        self.simulator = simulator
        self.name = name

        # Desenhar a fonte de tensão como um círculo com um símbolo
        self.body = self.canvas.create_oval(x - self.radius, y - self.radius, x + self.radius, y + self.radius, fill='white')
        self.symbol = self.canvas.create_text(x, y, text="+\n-", font=("Arial", 16))
        self.name_text = self.canvas.create_text(x, y + 30, text=f"{self.name} ({self.voltage}V)", font=("Arial", 10))

        # Associar o movimento à fonte de tensão
        self.canvas.tag_bind(self.body, "<Button1-Motion>", self.move)
        self.canvas.tag_bind(self.symbol, "<Button1-Motion>", self.move)
        self.canvas.tag_bind(self.name_text, "<Button1-Motion>", self.move)

    def move(self, event):
        dx, dy = event.x - self.x, event.y - self.y
        self.canvas.move(self.body, dx, dy)
        self.canvas.move(self.symbol, dx, dy)
        self.canvas.move(self.name_text, dx, dy)
        self.x, self.y = event.x, event.y
        self.simulator.update_results()

if __name__ == "__main__":
    root = tk.Tk()
    app = CircuitSimulator(root)
    root.mainloop()
